package com.keduit.bpro53.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class UploadTestController {

	@GetMapping("/uploadEx")
	public void uploadEx() {
		
	}
}

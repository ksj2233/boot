package com.keduit.bpro53.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.keduit.bpro53.entity.MovieImage;

public interface MovieImageRepository extends JpaRepository<MovieImage, Long>{

}
